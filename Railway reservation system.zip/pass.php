<?php
include"insert.php";
include"connection.php";
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Passenger details</title>  
    </head>
<style>
input[type=submit]{
   background-color:lightyellow;
   opacity: 0.8;
   width:20em;
   height:2em;
   font-size:20px;
   font-weight:bold;
}
Body {
    background-image:url('beauty.jpg');
    background-size:1500px 1000px;
}
#tabla{
    background-color:white;

}
#nb{
    background-color:pink;
    font-size:30px;
   font-weight:bold;
}
#taba{
    background-color:pink;
    font-weight:bold;
    opacity:0.9;
}
</style>
    <?php
   if(isset($_POST['back']))
   {
    header('location:adminn.php');
   }
   if(isset($_POST['home']))
   {
  header('location:co.php');
 }


 if(isset($_POST['troute']))
 {
   $sql = mysqli_query($db,"SELECT r.routid,r.fromstation,r.tostation,date,count(*)
                            FROM booking p,route r,train t
                            WHERE p.trainid=t.trainid
                            AND t.routid=r.routid
                            GROUP BY routid,date
                            order by routid;");
   $c=mysqli_num_rows($sql);
            
                  ?>
     <table align='center'border='1px' id='taba'style="width:600px; line-height:40px;"><strong>
     <tr>
 </tr>
 <tr><h1 align='center'>Total Tickets booked :<?php echo $c; ?></h1></tr>
        <t>
             <th>From station</th>
             <th>To station</th>
             <th>date</th>
             <th>no. of tickets booked</th>
             
        </t>
            <?php
            while($row=mysqli_fetch_array($sql))
            {
        ?>
        <tr>

            <td><?php echo $row['fromstation']; ?></td>
            <td><?php echo $row['tostation']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['count(*)']; ?></td>
        </tr>
        <?php
            }
         ?>


        </strong></table>
       <?php
   } 


  
if(isset($_POST['hhow']))
 {
    $d=$_POST['dat'];
    $sql = mysqli_query($db,"SELECT r.fromstation,r.tostation,count(*),u.fname
    FROM booking p,route r,train t,user u
    where p.trainid=t.trainid
    AND t.routid=r.routid
    AND r.routid='$d'
    and r.userid=;");
   
   $co=mysqli_num_rows($sql);

  ?>
  <table align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
  <tr>
 </tr>
 <tr><h1 align='center'> Number of seats booked on :
     <?php echo $d; ?></h1></tr>
<t>
<th>name</th>
<th>fromstation</th>
<th>tostation</th>
<th>count</th>


</t>
<?php
 while($row=mysqli_fetch_array($sql))
{
?>
<tr>
<td><?php echo $row['3']; ?></td>
<td><?php echo $row['0']; ?></td>
<td><?php echo $row['1']; ?></td>
<td><?php echo $row['2']; ?></td>

</tr>
<?php
 }
?>

</table>
<?php
}


if(isset($_POST['how'])){
?>
<section>

 <form name="details" action="" method="POST">
  <table id='nb' cellspacing="4px" cellpadding="4%"; align="center">
    <tr>
    <td>Enter the route  :</td>
    <td><input type="text" name="dat" required></td>
    </tr>
<tr align="center">
  <td></td> 
 <td>  <font font size='7'><input type="submit" value="Submit" name="hhow" ></td>
  
</tr>
</table>
</form>
</section>
<?php
}




 if(isset($_POST['pshow']))
  {
    $sql = mysqli_query($db,"SELECT p.pnr,p.pname,p.age,p.gender,p.date,p.mobileno,t.tname,r.fromstation,r.tostation
                    FROM booking p 
                    JOIN train t on p.trainid=t.trainid
                    JOIN route r on t.routid=r.routid;");
    $c=mysqli_num_rows($sql);
             
                   ?>
      <table align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
      <tr>
  </tr>
  <tr><h1 align='center'>Total Tickets booked :<?php echo $c; ?></h1></tr>
         <t>
              <th>pnr</th>
              <th>passenger name</th>
              <th>age</th>
              <th>gender</th>
              <th>date of travel</th>
              <th>mobile no.</th>
              <th>train name</th>
              <th>from station</th>
              <th>to station</th>
              
         </t>
             <?php
             while($row=mysqli_fetch_array($sql))
             {
         ?>
         <tr>
             <td><?php echo $row['pnr']; ?></td>
             <td><?php echo $row['pname']; ?></td>
             <td><?php echo $row['age']; ?></td>
             <td><?php echo $row['gender']; ?></td>
             <td><?php echo $row['date']; ?></td>
             <td><?php echo $row['mobileno']; ?></td>
             <td><?php echo $row['tname']; ?></td>
             <td><?php echo $row['fromstation']; ?></td>
             <td><?php echo $row['tostation']; ?></td>
         </tr>
         <?php
             }
          ?>


         </table>
        <?php
    } 
 
 
 ?>
    <body>
    <form action="pass.php" align='center' method="POST" >
    <input type="submit" name="troute" placeholder="id" value="No. of tickets booked for each route"><br><br>
    <input type="submit" name="pshow" placeholder="id" value="Show tickets booked"><br><br>
    <input type="submit" name="how" placeholder="id" value="Show tickets booked for particular date"><br><br>
    <input type="submit" name="home" placeholder="id" value="Home"><br><br>
    <input type="submit" name="back" placeholder="id" value="Back"><br><br>
        </form>
</body>
</html>