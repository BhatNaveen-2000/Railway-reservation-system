<?php
session_start();
$dd=$_SESSION['route'];
include"connection.php";
include"insert.php";
$res = mysqli_query($db,"SELECT * FROM `route` WHERE routid='$_SESSION[route]';");
while($row=mysqli_fetch_assoc($res))
{
     $f=$row['fromstation'];
     $l=$row['tostation'];
}
$r = mysqli_query($db,"SELECT p.pnr,p.pname,p.age,p.gender,p.date,p.mobileno,t.tname,t.trainid,r.fromstation,r.tostation,r.fare
FROM booking p 
INNER JOIN train t on p.trainid=t.trainid
INNER JOIN route r on t.routid=r.routid
WHERE pnr='$_SESSION[pnr]';");
while($row=mysqli_fetch_assoc($r)){
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Ticket Page</title>
        <h1 align='center' font-size='10'>This is your ticket take screenshot</h1>
</head>
<style>
#t1{
    font-size:30px;
    background-color:skyblue;
    border: 2px solid black;
    }
#m{
    font-size:30px;
}
input[type=submit]{
   background-color:black;
   color:white;
   opacity: 0.8;
   width:16em;
   height:2em;
   font-size:20px;
   font-weight:bold;
}
</style>
<body>
<section>
 <form name="Ticket" action="" method="POST">
    <table align='center' id='t1'>
        <h2 align='center'>
            Happy Journey!
        </h2>
     <tr>
      <td><p align='center'><strong>PNR : <?php echo $row['pnr'];?></strong></p></td> 
</tr>
     <tr>
         <td><p align='center'>passenger name:<?php echo $row['pname'];?>.     age:<?php echo $row['age'];?></p></td>
</tr>
<tr>
         <td><p align='center'>gender : <?php echo $row['gender'];?></p></td>
</tr><tr>
         <td><p align='center'>booked date : <?php echo $row['date'];?></p></td>
</tr>
<tr>
         <td><p align='center'>train name : <?php echo $row['tname'];?>!    id no.:<?php echo $row['trainid'];?></p></td>
</tr>
<tr>
         <td><p align='center'><?php echo $row['fromstation']; ?> to <?php echo $row['tostation'];?>.   Arriving time : 10:00 am</p></td>
</tr>
<tr>
         <td><p align='center'>Fare : <?php echo $row['fare'];?></p></td>
</tr>
</table>
<table id='m' align='center'>
<tr>
        <td><font font size='10'><input align="center" type="submit" value="logout" name="Submit" ></td>
</tr>
<tr>
        <td><font font size='10'><input align="center" type="submit" value="goto home" name="Go" ></td>
</tr>
</table>
<?php
}
if(isset($_POST['Go']))
    {
        header('location:co.php'); 
     }
if(isset($_POST['Submit'])){

$y=$_SESSION['tr'];
$k=$_SESSION['book'];
$res = mysqli_query($db,"SELECT * FROM `seats` WHERE trainid='$y' AND date='$k';");
$count=mysqli_num_rows($res);
/*if($count==0)
{
echo $count;*/
/*echo $se;
$sql="INSERT INTO seats(date,trainid,seats_rem) 
values('$k','$y','$se')";
if(mysqli_query($db,$sql))
{?>
<script>alert("record updated"); </script><?php
}}
else
{
$sql="UPDATE seats SET seats_rem=seats_rem-1 WHERE date='$k' AND trainid='$y'";*/

session_destroy();
header('location:index.php');
}

?>
</form>
</section>
</body>
</html>  
          
                       