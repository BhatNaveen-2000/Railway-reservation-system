<?php
  include"connection.php";
?>
<html>
<head>
<title>railway system</title>
<script language="javascript" ></script>
<style type="text/css">
Body {
    background-image:url("train.jpg");
    background-size:1500px 1000px;
}

h1{
    background-color: white;
}
input {
   
   font-size: 80%;
}
#m{
    width: 4em;
    height: 2em;
    font-size: 20px;
    padding:2px 3px;
    color: red;
}
#n{
    background-color: white;
    padding: 8px 5px;
}
#r{
    color: blue;
    background-color: yellow;
}
#table1{
    font-size:60px;
}
</style>
<body>


<h1 align="center">INDIAN RAILWAY RESERVATION SYSTEM </h1>
<marquee behavior="scroll" direction="left" id="r">University Visvesvaraya college of engineering
</marquee>

<form name="rail" action="" method="POST">

<div></br>
<table id="table1"; cellspacing="4px" cellpadding="4%"; align="center">
       <tr>
              <td bgcolor="pink" align="center"><font face="Comic Sans MS" font size="6"><b><i>USER NAME:</i></b></td>
              <td><font font size="6"><input type="text" name="username" required/></td>
       </tr>
       <tr>
              <td bgcolor="pink" align="center"><font face="Comic Sans MS" font size="6"><b><i>PASSWORD:</i></b></td>
              <td><font font size="6"><input type="password" name="password" /></td>
       </tr>
<tr>
<td></td>
<td ><font color="red" font size="20"><input   align="center" type="submit" id="m" name="login" value="login"  ></td>
</tr>
</table>
</div>
<pre><p align="center"><a href="reg.php" id="n"><font color="red" font size="6" backgroundcolor="white">Register</a></p></pre>
  <?php
    if(isset($_POST['login']))
    {
    $count = 0;
    
    $res = mysqli_query($db,"SELECT * FROM `user` WHERE userid='$_POST[username]' && password='$_POST[password]';");
        $count=mysqli_num_rows($res);
        if($count==0)
        {
            ?>
        <script type="text/javascript">
        alert("The username and password doesn't match");
       </script>
       <?php
        }
        else{
            session_start();

            $_SESSION['username']=$_POST['username'];
            
            
            header('location:co.php');
            ?>
        <script type="text/javascript">
             
        </script>
        <?php
        }
       }
        ?>
        
        
    
</body>

</head></form></html>
