<?php
  include"insert.php";
  include"connection.php";
  session_start();
  $jj=$_SESSION['username'];
  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>railway</title>
<h1 align='center'><strong>Welcome to our website</strong></h1>
<script language="javascript" ></script>
<style type="text/css">
Body {
    background-color:lightgreen;
    background-size:1500px 1000px;
}
input[type=submit]{
   background-color:lightpink;
   opacity: 0.8;
   width:14em;
   height:2em;
   font-size:20px;
   font-weight:bold;
}
table.kl{
   background-color:white;
   opacity: 0.8;
   font-weight:bold;
}
input.control{
   width:14em;
   height:1.5em;
   font-size:20px;
   font-weight:bold;
}
div.form{
    justify-content: center;
    background-size:1500px 1000px;
    font-size: larger;
    top:40%;
    left:50%;
}


</style>
<?php
if(isset($_POST['cance']))
{
    $fn = filter_input(INPUT_POST, 'pnr'); 
    $count=0;
    $sql= "DELETE FROM booking WHERE pnr=$fn AND userid=$jj";
    $re= mysqli_query($db,"SELECT date,trainid FROM booking WHERE pnr='$fn' AND userid='$jj';");
    while($row=mysqli_fetch_assoc($re))
    {
      $ar=$row['date'];
      $r=$row['trainid'];
    }
    $count=mysqli_num_rows($re);
    if($count>0){
    if (mysqli_query($db,$sql)){
        $sql="UPDATE seats
              SET seats_rem=seats_rem+1 
              WHERE date='$ar' AND trainid=$r";
        if(mysqli_query($db,$sql)){
     ?>
 
     <script type="text/javascript">
     alert("Your ticket cancelled successfully ");
  
   </script>
   <?php
    
}}}
else{?>
    <script type="text/javascript">
     alert("Enter correct pnr number ");
    </script>
   <?php
}
 }
if(isset($_POST['Cancel']))
    {?>
        <form name="de" action="" method="POST">
        <table cellspacing="4px" cellpadding="4%"; fontsize="40px" align="center">
         <tr><font font size='8'>
          <td><font font size='8'>Enter your pnr to cancel the ticket :
          <input class="control" type="text" name="pnr" required></td>
         </tr>
         <tr>
           <td align="center"><input  type="submit" value="Cancel" name="cance"></td>
         </tr>
    </table>
    </form>
 <?php
}

if(isset($_POST['Book']))
  {
    header('location:conn.php');
  }
  if(isset($_POST['History']))
  {
    $sql = mysqli_query($db,"SELECT p.pnr,p.pname,p.age,p.gender,p.date,p.mobileno,t.tname,r.fromstation,r.tostation
                    FROM booking p 
                    INNER JOIN train t on p.trainid=t.trainid
                    INNER JOIN route r on t.routid=r.routid
                    WHERE userid='$_SESSION[username]';");
    $c=mysqli_num_rows($sql);
             
                   ?>
      <table class='kl' align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
      <tr>
  </tr>
  <tr><h1 align='center'> Tickets booked by your account is:<?php echo $c; ?></h1></tr>
         <t>
              <th>pnr</th>
              <th>passenger name</th>
              <th>age</th>
              <th>gender</th>
              <th>date of travel</th>
              <th>mobile no.</th>
              <th>train name</th>
              <th>from station</th>
              <th>to station</th>
              
         </t>
             <?php
             while($row=mysqli_fetch_array($sql))
             {
         ?>
         <tr>
             <td><?php echo $row['pnr']; ?></td>
             <td><?php echo $row['pname']; ?></td>
             <td><?php echo $row['age']; ?></td>
             <td><?php echo $row['gender']; ?></td>
             <td><?php echo $row['date']; ?></td>
             <td><?php echo $row['mobileno']; ?></td>
             <td><?php echo $row['tname']; ?></td>
             <td><?php echo $row['fromstation']; ?></td>
             <td><?php echo $row['tostation']; ?></td>
         </tr>
         <?php
             }
          ?>


         </table>
        <?php
    } 
 if(isset($_POST['Admin']))
  { ?><form name="adm" action="" method="POST">
      <table align='center'font size="10"><font font size='8'>
        <tr>
        <td><font font size='8'>Enter your adminkey:
        <font font size='8'><input class="control" type="password" size='20' name="name"></td>
        </tr>
        <tr align="center">
        <td align='center'><font color="red" font size="20"><input   type="submit" id="m" name="log" value="login" ></td>
        </tr>
       </table>
    </form>
       <?php
        
        }
    if(isset($_POST['back']))
    {
        header('location:index.php');
    }
    if(isset($_POST['log']))
        {
         $count = 0;
            
        $res = mysqli_query($db,"SELECT * FROM `admin` WHERE akey='$_POST[name]';");
             $count=mysqli_num_rows($res);
            if($count==0)
                {
                    ?>
                <script type="text/javascript">
                alert("The admin key is wrong");
               </script>
               <?php
                }
            else{
            echo $count;
            header('location:adminn.php');
            }
        }
            ?>




</head>
<body>
<div class="form">
<form name="useradmin" action="co.php" method="POST">
  <table id='idd' cellspacing="1px" cellpadding="2%"; align="center"> 
 <tr>
 <td>  <font font size='15'><input type="submit" value="Login as admin" name="Admin" ></td>
 </tr>
 <tr>
 <td>  <font font size='15'><input type="submit" value="Book Train" name="Book" ></td>
</tr>
<tr>
 <td>  <font font size='15'><input type="submit" value="History of user" name="History" ></td>
</tr>
<tr>
 <td>  <font font size='15'><input style='height:50px;'type="submit" value="Cancel Ticket" name="Cancel" ></td>
</tr>
<tr>
 <td>  <font font size='15'><input type="submit" value="logout" name="back" ></td>
</tr>
</table>
</form>
</div>
</body>
</html>