<?php
include"connection.php";
include"insert.php";
session_start();
$root=$_SESSION['route'];
?>
<?php
$c=0;
$res = mysqli_query($db,"SELECT * FROM `train` WHERE routid=$root;");
$c=mysqli_num_rows($res);
echo $c;
?>
<!DOCTYPE html>
<html>

    <head>
        <title>Train selection</title>
    </head>
        <style>
Body {
    background-image:url("wallpaper1.jpg");
    background-size:1500px 1000px;
}
input[type=submit]{
    font-size:0.5em;
}
#g{
    background-color:yellow;
    opacity: 0.8;
}
    
#tabla{
    font-size:25;
    background-color:white;
}
h1{
    background-color:black;
    
    opacity: 0.8;
}
</style>
</table id='r'>
         <h1 align='center' ><font font-size="20" color='white'><strong>Select train for route :<?php echo $_SESSION['route']?></strong></h1>
        
    <form name="gtrain" action="" method="POST" >
        <body>
         <table align='center'border='1px' id='tabla'style="width:600px; line-height:40px;">
         <tr>
     </tr>
            <t>
                 <th>trainid</th>
                 <th>train name</th>
                 
            </t>
                <?php
                while($row=mysqli_fetch_array($res))
                {
            ?>
            <tr>
                <td><?php echo $row['trainid']; ?></td>
                <td><?php echo $row['tname']; ?></td>
                
            </tr>
            <?php
                }
             ?>


            </table>
<table align='center' >
    <tr>
            </tr>
    <tr>
    <td id='g' align="left"><font font size='8' > Enter the id of  train :</td>
    <td><font font size='12'><input type="text" id="tr" name="tr" required/></td>
            </tr>
            <tr>
  <td align='center'><font font size='12'><input align='center' type="submit" value="next" name="waste">
  </td>
</tr>
            </table>
            </form>
            </table>
        <?php
    
    if(isset($_POST['waste']))
    {
    $count = 0;
    $re = mysqli_query($db,"SELECT * FROM `train` WHERE trainid='$_POST[tr]' AND routid='$_SESSION[route]';");
    while($row=mysqli_fetch_assoc($re))
    {
      $ar=$row['seat'];
      $tnm=$row['tname'];
      $sss=$row['seat'];
    }
    $count=mysqli_num_rows($re);
    if($count==0)
        {
            ?>
            
        <script type="text/javascript">
        alert("Enter correct train id");
       </script>
       <?php
        }
        else
        {
        $_SESSION['sss']=$sss;
        $_SESSION['seat']=$ar;
        $_SESSION['tname']=$tnm;
        $_SESSION['tr']=$_POST['tr'];
        header('location:imp.php');
        }
      }
            ?>
</body>

</html>
