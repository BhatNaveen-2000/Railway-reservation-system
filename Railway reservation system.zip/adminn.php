<?php
include"insert.php";
include"connection.php";
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>PHP : Train and Route</title>  
</head>
<style>
input[type=submit]{
   background-color:orange;
   opacity: 0.8;
   width:14em;
   height:2em;
   font-size:20px;
   font-weight:bold;
}
</style>
>
    <?php
    if(isset($_POST['train']))
    {
     header('location:man.php');
    }
    if(isset($_POST['pass']))
    {
     header('location:pass.php');
    }
    if(isset($_POST['back']))
    {
     header('location:co.php');
    }
    if(isset($_POST['show']))
    {
        $sql = mysqli_query($db,"SELECT * from route;");
        $c=mysqli_num_rows($sql);
 
       ?>
       <table align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
       <tr>
      </tr>
      <tr><h1 align='center'> Total number of routes are:<?php echo $c; ?></h1></tr>
      <t>
      <th>Routid</th>
      <th>From</th>
      <th>To</th>
      <th>Distance</th>
      <th>Fare</th>
  
     </t>
     <?php
       while($row=mysqli_fetch_array($sql))
       {
        ?>
       <tr>
     <td><?php echo $row['routid']; ?></td>
    <td><?php echo $row['fromstation']; ?></td>
    <td><?php echo $row['tostation']; ?></td>
    <td><?php echo $row['distance']; ?></td>
    <td><?php echo $row['fare']; ?></td>

      </tr>
       <?php
         }
       ?>


     </table>
    <?php
    }
   if(isset($_POST['d']))
    {
        $fn = filter_input(INPUT_POST, 'rid'); 
        $count=0;
        $sql= "DELETE FROM route WHERE routid=$fn"; 
        $re= mysqli_query($db,"SELECT * FROM route WHERE routid='$fn';");
        $count=mysqli_num_rows($re); 
        if($count>0){
        if ($conn->query($sql)){
         ?>
     
         <script type="text/javascript">
         alert("route deleted successfully ");
      window.location="adminn.php"
      
       </script>
       <?php
    }
   }
    else{
        ?><script>alert("Enter correct rout id");</script><?php
    }
     }

    if(isset($_POST['del']))
    {?>
        <form name="de" action="" method="POST">
        <table cellspacing="4px" cellpadding="4%"; align="center">
         <tr>
          <td><font font size='8'>Enter id of the route to delete :
          <input class="form_control" type="text" name="rid" required></td>
         </tr>
         <tr>
           <td align="center"><input  type="submit" value="Delete" name="d"></td>
         </tr>
    </table>
    </form>
    <?php
    }
    if(isset($_POST['add']))
                   {
                   $fname = filter_input(INPUT_POST, 'fst');
                   $lname = filter_input(INPUT_POST, 'tst');
                   $gender = filter_input(INPUT_POST, 'dis');
                   $password = filter_input(INPUT_POST, 'fare');
                      $sql = "INSERT INTO route (fromstation,tostation,distance,fare)
                       values ('$fname','$lname','$gender','$password')";
            
                       if ($conn->query($sql)){
                          $last_id=$conn->insert_id
                       ?>
                   
                   <script type="text/javascript">
                    alert("New route added successfully ");
                    var last_id='<?php echo $last_id?>'
                    alert("The new route id is "+last_id);
                    
                        window.location="adminn.php"
                    
                  </script>
                   <?php
            }
        }
    if(isset($_POST['rout']))
    {?>
        <form name="add" action="" method="POST"><font font size='6'>
        <table cellspacing="4px" cellpadding="4%"; align="center"><font text size='8'>
         <tr>
          <td>From station :</td>
          <td><input class="form_control" type="text" name="fst" required></td>
         </tr>
         <tr>
          <td>To station :</td>
          <td><input class="form_control" type="text" name="tst" required></td>
         </tr>
         <tr>
          <td>distance(in km) :</td>
          <td><input class="form_control" type="text" name="dis" required></td>
         </tr>
         <tr>
          <td>Fare(in Rupees) :</td>
          <td><input class="form_control" type="text" name="fare" required></td>
         </tr>
         <tr align="center">
           <td align="center"><input  type="submit" value="Add the route" name="add"></td>
         </tr>
    </table>
    </form>
        <?php
        
        
    }
    if(isset($_POST['route']))
    { 
    ?>
        
        <form action="adminn.php" align='center' method="POST" >
        <input type="submit" name="rout" placeholder="id" value="add new route"><br><br>
        <input type="submit" name="show" placeholder="id" value="Show all the routes"><br><br>
        <input type="submit" name="del" placeholder="id" value="delete the route"><br><br>
        </form>
        <?php
    }
    ?>
    <body>
        <form action="adminn.php" align='center' method="POST" >

            <input type="submit" name="train" placeholder="id" value="Train management"><br><br>
            <input type="submit" name="route" placeholder="id" value="Route management"><br><br>
            <input type="submit" name="pass" placeholder="id" value="Ticket management"><br><br>
            <input type="submit" name="back" placeholder="id" value="Home"><br><br>
            <!--<input type="text" name="fname" placeholder="First Name" value=""><br><br>
            <input type="text" name="lname" placeholder="Last Name" value=""><br><br>
            <input type="number" min="10" max="100" name="age" placeholder="Age" value=""><br><br>
            
            <input type="submit" name="insert" value="Insert">
            <input type="submit" name="update" value="Update">
            <input type="submit" name="delete" value="Delete">
            <input type="submit" name="search" value="Search">-->

        </form>
        
    </body>    
</html>