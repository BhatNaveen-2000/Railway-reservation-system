$fname = filter_input(INPUT_POST, 'fname');
$lname = filter_input(INPUT_POST, 'lname');
$gender = filter_input(INPUT_POST, 'gender');
$password = filter_input(INPUT_POST, 'password');
if (!empty($fname)){
if (!empty($password)){



if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO user (fname,lname,gender,password)
values ('$fname','$lname','$gender','$password')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully. Go login page to book";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Password should not be empty";
die();
}
}
else{
echo "name should not be empty";
die();
}
?>





if(isset($_POST['Submit']))
       {
           mysqli_query($db,"INSERT INTO `user`(fname,lname,gender,password)
           values ('$_POST[fname]','$_POST[lname]','$_POST[gender]','$_POST[password]');");
       ?>
       <script type="text/javascript">
        alert("Registration successfull ");
        alert("Go to login page ");
       </script>
       <?php
       }
       ?>


