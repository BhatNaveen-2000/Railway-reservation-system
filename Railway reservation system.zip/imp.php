<?php
include"connection.php";
include"insert.php";
session_start();
$dd=$_SESSION['route'];
$d=$_SESSION['book'];
echo $d;
?>
<!DOCTYPE HTML>
<html>
<head>
  <title>Passenger details</title>

<style type="text/css">
table {
  font-size: larger;
}
input {
   
   font-size: 60%;
}
td{
    font-size: 160%;
}
body{
    justify-content: center;
    background-image:url("photo.jpg");
    background-size:1500px 1000px;
    font-size: larger;
}
#b{
    background-color: orange;
    opacity: 0.9;
    
    }
#u{
background-color: lightgreen;
opacity: 0.7;
    
    }  

</style>
</head>
<body>

<section>

 <form name="passengerdetails" action="" method="POST">
  <table id='b' cellspacing="4px" cellpadding="4%"; align="center">
    <tr>
    <td>Passenger Name :</td>
    <td><input class="form_control" type="text" name="pname" required></td>
    </tr>
   <tr>
    
    <td>age :</td>
    <td><input class="form_control" type="text" name="age" required></td>
    </tr>
    <tr>
    
    <td>Gender :</td>
    <td>
     <input class="form_control" type="radio" name="gender" value="m" required>Male
     <input class="form_control" type="radio" name="gender" value="f" required>Female
    </td>
   </tr>
   <tr>
    
    <td>Mobile no. :</td>
    <td><input class="form_control" type="int" name="mob" required></td>
</tr>

</table>
<table cellspacing="4px" cellpadding="4%"; align="center">
    <tr>
   <td><p align='center' id='u'><font  font size='8'>Your travel fare is :<?php echo $_SESSION['fare']?> Rupees</p></td>
     </tr>
</table>
<table align='center'>
<tr>
   <td><font font size='7'><input align="center" type="submit" value="Pay and book the ticket" name="Submit" >
  </td>
</tr>
<td>
<p align="center"><a href="index.php" id="n"><font color="red" font size="6" backgroundcolor="white">logout</a></p></td>
</tr>
</table>
</form>
</section>
<?php
$pname = filter_input(INPUT_POST, 'pname');
$age = filter_input(INPUT_POST, 'age');
$gender = filter_input(INPUT_POST, 'gender');
$mob = filter_input(INPUT_POST, 'mob');
$im=$_SESSION['username'];
$oo=$_SESSION['tr'];

       if(isset($_POST['Submit']))
       { 
        
        
        $_SESSION['pn']=$_POST['pname'];
        $_SESSION['ag']=$_POST['age'];
        $_SESSION['ge']=$_POST['gender'];
        $_SESSION['n']=$_POST['mob'];
        $sql = "INSERT INTO booking (pname,age,gender,mobileno,userid,trainid,date)
        values ('$pname','$age','$gender','$mob','$im','$oo','$d')";

        if ($conn->query($sql)){
            $last_id=$conn->insert_id
              
           ?>
       
       <script type="text/javascript">
        alert("Your payment is successful and you have booked the ticket");
        var last_id='<?php echo $last_id?>'
        alert("remember your PNR number is "+last_id);
        
        window.location="next.php"
        
      </script>
       <?php
       
        }    
      }
       ?>

</body>
</html>

