<?php
include "connection.php";
include "insert.php";
session_start();
$re = mysqli_query($db,"SELECT * FROM `route`");
$m=mysqli_num_rows($re);
ob_start();
?>
<!DOCTYPE 
  <html>
  <head>
  <title>PLAN MY JOURNEY</title>
  <style type="text/css">
Body {
    background-color:skyblue;
    background-size:1500px 1000px;
}
.box{
    background-color:lightgreen ;
    opacity: 0.8;
}
td{
  font-size:23;
}
#p{
  font-size:30px;
  background-color:
}
nav{
  margin: 0px;
  padding: 0px;
  list-style: none;
  font-size: 30px;
  
}
ul {
  float: left;
  width: 400px;
  align: right;
}
</style>
<h1 align="center"><font font size="30">Select your route</h1>
  </head>
  
  
 <!-- <header>
    <nav>
      <div align='right' id='p' class='menu'>
        <a href="cancel.html">Cancel</a>
        <a href="display.html">Display Ticket</a>
        
</div>
</nav>
</header>-->
  <body>
  <form name="conn" action="" method="POST" >
  <!--<pre><p align="right"><a href="cancel.html">cancel</a>  <a href="cancel.html">cancel</a></pre> --> 
  
  <section>
  <div class="box">
  <table align='center'border='1px' id='tabla'style="width:600px; line-height:40px;">
         <tr>
     </tr>
            <t>
                <th>routid</th>
                <th>source</th>
                <th>destination</th>
                <th>distance</th>
                <th>fare</th>
            </t>
                <?php
                while($row=mysqli_fetch_array($re))
                {
            ?>
            <tr>
                <td><?php echo $row['routid']; ?></td>
                <td><?php echo $row['fromstation']; ?></td>
                <td><?php echo $row['tostation']; ?></td>
                <td><?php echo $row['distance']; ?></td>
                <td><?php echo $row['fare']; ?></td>
                </tr>
            <?php
                }
             ?>
</table>
   
 <table align='center'>
  <tr>
  <td align="left"><font > Enter your route id(just number) :</td>
  <td><font font size="5"><input type="text" id="route" name="route" required/></td>
    <!--<option  value="1">Bengaluru to Hyderabad</option>
    <option  value="2">Hyderabad to Bengaluru</option>
    <option  value="3">Bengaluru to Chennai</option>
    <option  value="4">Chennai to Bengaluru</option>
    <option  value="5">Bengaluru to Hubli </option>
    <option  value="6">Hubli to Bengaluru</option>-->


  <tr>
 <!-- <td><font face="Forte" font size="10"> Journey Date: </td>
  <td><input type="'date" id="dat" name="dat" > </td>-->
  <td><label align="left"><font  for="book">Select Date:</label></td>
   <td>  <input type="date" id="book" name="book" onchange='Tdate()' required/></td>
  </tr>
  <tr>
  <script>
  function TDate() {
    var UserDate = document.getElementById("userdate").value;
    var ToDate = new Date();

    if (new Date(UserDate).getTime() <= ToDate.getTime()) {
          alert("The Date must be Bigger or Equal to today date");
          return false;
     }
    return true;
}
</script>
      
  <!-- <td><label align="left"><font face="Forte" font size="10" for="book">Select Train:</label></td>
   <td>  <input type="" id="book" name="book"></td>-->
  
 
  </tr>
  <tr>
  </tr>
  <tr align='center' >
  <td><font font size='19'><input  align='center' type="submit" value="next" name="next">
  </td>
</tr>
</table>
</div>
</section>
  </form>
  
  <?php
  /*var catcheck=document.getElementById("catid").selectedIndex;
  catcheck=catcheck+1;
  echo "catcheck=".catcheck;
  document.write(catcheck);
  
   /* var catcheck=document.getElementById("catid").selectedIndex;
  catcheck=catcheck+1;
   document.getElementById("demo").innerHTML = catcheck;*/
    
  
  
    if(isset($_POST['next']))
    {
   
    $date='2021-02-24';
    if($_POST['book'] < $date)
    {
      ?>
      <script type="text/javascript">
      alert("Select appropriate date. It must be larger than current date");
     </script>
     <?php
    }
    else{
      $count = 0;
    $res = mysqli_query($db,"SELECT * FROM `route` WHERE routid='$_POST[route]';");
    while($row=mysqli_fetch_assoc($res))
    {
      $var=$row['distance'];
      $vr=$row['fare'];
    }

    $count=mysqli_num_rows($res);
      if($count==0)
        {
            ?>
            
        <script type="text/javascript">
        alert("Enter correct route");
       </script>
       <?php
        }
        else
        {
          $_SESSION['book']=$_POST['book'];
          $_SESSION['distance']=$var;
          $_SESSION['fare']=$vr;
          $_SESSION['route']=$_POST['route'];
          header('location:gtrain.php');
        }
      }
    }
    ob_end_flush();
            ?>
        <script >
             
        </script>
        
        
  </body>
  </html>   




