<?php 
$db=mysqli_connect("localhost","root","","train.db");
if(!$db)
{
    die("Connection failed:" .mysqli_connect_error());
    echo "nottt";
}

?>