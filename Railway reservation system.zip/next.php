<?php
include"connection.php";
include"insert.php";
session_start();
$dd=$_SESSION['route'];
?>
<!DOCTYPE HTML>
<html>
<head>
  <title>PNR</title>

<style type="text/css">
table {
  font-size: larger;
  background-color: pink;
  opacity: 0.8;

}
input {
   font-size: 60%;
   align:center;
}
td{
    font-size: 160%;
}
body{
    justify-content: center;
    background-image:url("imm.jpg");
    background-size:1500px 1000px;
    font-size: larger;
    position:fixed;
    margin-left:-150px;
    margin-right:-150px;
    top:40%;
    left:40%;
}
</style>
</head>
<body>
<section>

 <form name="passengerdetails" action="" method="POST">
  <table id='b' cellspacing="4px" cellpadding="4%"; align="center">
    <tr>
    <td>Enter your pnr  :</td>
    <td><input type="text" name="PNR" required></td>
    </tr>
<tr align="center">
  <td></td> 
 <td>  <font font size='7'><input type="submit" value="Generate the ticket" name="Submit" ></td>
  
</tr>
</table>
</form>
</section>
 
<?php
if(isset($_POST['Submit'])){
$count = 0;
$y=$_SESSION['tr'];
$k=$_SESSION['book'];
$se=$_SESSION['sss'];
$me=$se-1;
$res = mysqli_query($db,"SELECT * FROM `booking` WHERE userid='$_SESSION[username]' AND pnr='$_POST[PNR]';");
    $count=mysqli_num_rows($res);
    if($count==0)
    {
        ?>
    <script type="text/javascript">
    alert("The pnr number you entered is wrong");
    </script>
    <?php
    }
    else{
        
        
        $sql="INSERT INTO seats(date,trainid,seats_rem) 
             values('$k','$y','$me')
             ON DUPLICATE KEY UPDATE seats_rem=seats_rem-1";

        if(mysqli_query($db,$sql))
       {?>
       <script>alert("record updated!"); </script><?php
       $_SESSION['pnr']=$_POST['PNR'];
        
       header('location:ticket.php');
       }
   }
}
?>
 </body>
 </html>
    
    <!--  /*$sql = "INSERT INTO booking (pname,age,gender,mobileno)
     values ('$pname','$age','$ender','$mobile')";

     $count = 0;
           $y=$_SESSION['tr'];
           $res = mysqli_query($db,"SELECT * FROM `seats` WHERE trainid='$_SESSION[tr]' AND date='$_SESSION[book]';");
           $count=mysqli_num_rows($res);
           if($count==0)
            {
            $sql="INSERT INTO seats(date,trainid,seats_booked) 
              values('$_SESSION[book]','$_SESSION[tr]','$_SESSION[seat]')";
            }
            else
            {
             mysql_query("UPDATE seats SET seats_rem=seats_rem-1 WHERE trainid='".$y."'");
            }
        
         if ($conn->query($sql)){
              $last_id=$conn->insert_id*/-->
           
  