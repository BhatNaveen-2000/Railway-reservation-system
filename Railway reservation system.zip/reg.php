<?php
  include"insert.php";
?>

<!DOCTYPE HTML>
<html>
<head>
  <title>Register Form</title>
<style type="text/css">
table {
  font-size: larger
}
input {
   
    
   font-size: 60%;
}
td{
    font-size: 160%;
}
body{
    background-color: rgb(240, 195, 202);
    font-size: larger;
}
</style>
</head>
<body>
<h1>
</h1>
<section>
 <form name="Registration" action="" method="POST">
  <table cellspacing="4px" cellpadding="4%"; align="center">
   <tr>
    <td>First Name :</td>
    <td><input class="form_control" type="text" name="fname" required></td>
   </tr>
   <tr>
    
    <td>Last Name :</td>
    <td><input class="form_control" type="text" name="lname" required></td>
   </tr>
   <tr>
    
    <td>Gender :</td>
    <td>
     <input class="form_control" type="radio" name="gender" value="m" required>Male
     <input class="form_control" type="radio" name="gender" value="f" required>Female
    </td>
   </tr>
   <tr>
    
    <td>Password :</td>
    <td><input class="form_control" type="text" name="password" required></td>
   </tr>
   <tr>
   <td>email :</td>
    <td><input class="form_control" type="text" name="email" required></td>
   </tr>
   <tr>
   <td>Contact N0. :</td>
    <td><input class="form_control" type="text" name="mob" required></td>
   </tr>
   <!--<tr>
    <td>Email :</td>
    <td><input type="email" name="email" required></td>
   </tr> 
   <tr>
    <td>Phone no :</td>
    <td>
     <select name="phoneCode" required>
      <option selected hidden value="">Select Code</option>
      <option value="977">977</option>
      <option value="978">978</option>
      <option value="979">979</option>
      <option value="973">973</option>
      <option value="972">972</option>
      <option value="974">974</option>
     </select>
     <input type="phone" name="phone" required>
    </td>
   </tr>-->
   <tr>
    
    <td><input  type="submit" value="Submit" name="Submit"></td>
   </tr>
  </table>
 </form>
</section>
<?php
$fname = filter_input(INPUT_POST, 'fname');
$lname = filter_input(INPUT_POST, 'lname');
$gender = filter_input(INPUT_POST, 'gender');
$password = filter_input(INPUT_POST, 'password');
$email = filter_input(INPUT_POST, 'email');
$mob = filter_input(INPUT_POST, 'mob');
       if(isset($_POST['Submit']))
       {
          $sql = "INSERT INTO user (fname,lname,gender,password,email,mob)
           values ('$fname','$lname','$gender','$password','$email','$mob')";

           if ($conn->query($sql)){
              $last_id=$conn->insert_id
           ?>
       
       <script type="text/javascript">
        alert("Registration successfull ");
        var last_id='<?php echo $last_id?>'
        alert("remember your id is "+last_id);
        
             window.location="index.php"
        
      </script>
       <?php
       echo "remember your userid is : ".$last_id;
       echo "  and password is : ".$password;
       }
      }
       ?>




</body>
</html>

