<?php
include"insert.php";
include"connection.php";
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Train management</title>  
    </head>
<style>
input[type=submit]{
   background-color:black;
   color:white;
   opacity: 0.8;
   width:16em;
   height:2em;
   font-size:20px;
   font-weight:bold;
}
Body {
    background-color:lightyellow;
    background-size:1500px 1000px;
}
form.fo{
    justify-content: center;
    background-size:1500px 1000px;
    font-size: larger;
    top:40%;
    left:50%;
}
#fo{
    background-color:lightpink;
   
}
#tabla{
    background-color:lightgreen;
    font-weight:bold;
    opacity: 0.9;
}
table{
    background-color:white;
    color:black;
    background-size:1500px 1000px;
}
</style>
<?php
 if(isset($_POST['back']))
 {
  header('location:adminn.php');
 }
 if(isset($_POST['home']))
 {
  header('location:co.php');
 }

 if(isset($_POST['showin']))
 {
    $sql = mysqli_query($db,"SELECT t.trainid,t.tname,t.seat-b.seats_rem,b.date FROM train t
                             INNER JOIN seats b
                             ON
                             t.trainid=b.trainid;");
   
   $co=mysqli_num_rows($sql);

  ?>
  <table align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
  <tr>
 </tr>
 <tr><h1 align='center'> Train with no. of seats booked</h1></tr>
<t>
<th>Trainid</th>
<th>Train name</th>
<th>No. of seats booked</th>
<th>date</th>

</t>
<?php
 while($row=mysqli_fetch_array($sql))
{
?>
<tr>
<td><?php echo $row['trainid']; ?></td>
<td><?php echo $row['tname']; ?></td>
<td><?php echo $row['2']; ?></td>
<td><?php echo $row['date']; ?></td>

</tr>
<?php
 }
?>

</table>
<?php
}


   if(isset($_POST['shoo']))
     {
        $sql = mysqli_query($db,"SELECT trainid,tname,seat,r.fromstation,r.tostation
                                 FROM train  
                                JOIN route r on train.routid=r.routid
                                ORDER BY trainid;");
       
       $co=mysqli_num_rows($sql);

      ?>
      <table align='center'border='1px' id='tabla'style="width:900px; line-height:40px;">
      <tr>
     </tr>
     <tr><h1 align='center'> Total number of Trains are:<?php echo $co; ?></h1></tr>
    <t>
   <th>Trainid</th>
    <th>Train name</th>
    <th>No. of seats</th>
    <th>From Station</th>
    <th>To Station</th>

   </t>
   <?php
     while($row=mysqli_fetch_array($sql))
    {
    ?>
   <tr>
    <td><?php echo $row['trainid']; ?></td>
    <td><?php echo $row['tname']; ?></td>
    <td><?php echo $row['seat']; ?></td>
    <td><?php echo $row['fromstation']; ?></td>
    <td><?php echo $row['tostation']; ?></td>

  </tr>
   <?php
     }
   ?>

</table>
<?php
}

    if(isset($_POST['dt']))
       {
           $fn = filter_input(INPUT_POST, 'tid');
           $count=0; 
           $sql= "DELETE FROM train WHERE trainid=$fn";
           $re= mysqli_query($db,"SELECT * FROM train WHERE trainid='$fn';");
           $count=mysqli_num_rows($re); 
           if($count>0){
           if ($conn->query($sql)){
               
            ?>
        
            <script type="text/javascript">
            alert("train deleted successfully ");
         window.location="man.php"
         
          </script>
          <?php
           }
       }
       else{
           ?><script>alert("Enter correct train id");</script><?php
       }
    }
    if(isset($_POST['adt']))
    {
    $fname = filter_input(INPUT_POST, 'na');
    $lname = filter_input(INPUT_POST, 'se');
    $gender = filter_input(INPUT_POST, 'ro');
    
       $sql = "INSERT INTO train (tname,seat,routid)
        values ('$fname','$lname','$gender')";

        if ($conn->query($sql)){
           $last_id=$conn->insert_id
        ?>
    
    <script type="text/javascript">
     alert("New train added successfully ");
     var last_id='<?php echo $last_id?>'
     alert("The new train id is "+last_id);
     
         window.location="man.php"
     
   </script>
    <?php
}
}
    if(isset($_POST['new']))
          {?>        

<table align='center' border='1px' id='tabal'style="width:600px; line-height:30px;">
         <tr>
     </tr>
            <t>
                <th>routid</th>
                <th>source</th>
                <th>destination</th>
                <th>distance</th>
                <th>fare</th>
            </t>
                <?php
                $re = mysqli_query($db,"SELECT * FROM `route`");
                while($row=mysqli_fetch_array($re))
                {
            ?>
            <tr>
                <td><?php echo $row['routid']; ?></td>
                <td><?php echo $row['fromstation']; ?></td>
                <td><?php echo $row['tostation']; ?></td>
                <td><?php echo $row['distance']; ?></td>
                <td><?php echo $row['fare']; ?></td>
                </tr>
            <?php
                }
             ?>
</table>



        <form name="addt" action="" method="POST"><font text size='6'>
            <table id='fo'cellspacing="4px" cellpadding="4%"; align="center">
               <tr>
                <td>Train name :
                <input class="form_control" type="text" name="na" required></td>
               </tr>
               <tr>
                <td>Total no. of seats :
                <input class="form_control" type="text" name="se" required></td>
               </tr>
               <tr>
                <td>Enter routid for train:
                <input class="form_control" type="text" name="ro" required></td>
               </tr>
               <tr>
                 <td align="center"><input  type="submit" value="Add the Train" name="adt"></td>
               </tr>
          </table>
          </form>
              <?php
     }

     if(isset($_POST['dele']))
        {?>
         <form name="deleting" action="" method="POST"><font text size='6'>
         <table cellspacing="4px" cellpadding="4%"; align="center">
          <tr>
           <td>Enter id of the Train to delete :
           <input class="form_control" type="text" name="tid" required></td>
          </tr>
          <tr>
            <td align="center"><input  type="submit" value="Delete the train" name="dt"></td>
          </tr>
        </table>
        </form>
       <?php
        }

   
?>
<body>
<form class='fo'action="man.php" align='center' method="POST" >
    <input type="submit" name="new" placeholder="id" value="add new train"><br><br>
    <input type="submit" name="shoo" placeholder="id" value="Show all the trains with routes"><br><br>
    <input type="submit" name="showin" placeholder="id" value="Seats booked in train"><br><br>
    <input type="submit" name="dele" placeholder="id" value="delete the trains"><br><br>
    <input type="submit" name="home" placeholder="id" value="Home"><br><br>
    <input type="submit" name="back" placeholder="id" value="Back"><br><br>
        </form>
</body>
</html>